UNBOUND_LOG_FILE = "/var/lib/unbound/unbound.log"
DNS_PROXY_LOG_FILE = "/var/log/dns_proxy.log"
LOG_FILE = "/var/log/dns_log_parser.log"
WINDOW_SECONDS = 5
MAX_STORAGE_SECONDS = 24 * 60 * 60
MAX_LINES_PER_READ = 1000
SERVER_PORT = 8000