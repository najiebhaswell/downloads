from dns_proxy.log_parser.main import main

if __name__ == "__main__":
    main()