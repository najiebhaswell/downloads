from dns_proxy.blacklist_updater.updater import main

if __name__ == "__main__":
    main()