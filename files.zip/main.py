from dns_proxy.server.main import main

if __name__ == "__main__":
    main()